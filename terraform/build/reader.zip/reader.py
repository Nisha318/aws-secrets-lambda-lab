import os
import boto3

DDB_TABLE = os.environ["DDB_TABLE"]

dynamodb = boto3.resource("dynamodb")

def lambda_handler(event, context):
    table = dynamodb.Table(DDB_TABLE)
    resp = table.scan()

    print("---------------------------------------")
    print(" Secure Secret Retrieval Demo")
    print(" Owner: Nisha")
    print("---------------------------------------")

    print("------------ STUDENT DETAILS -----------")

    for item in resp.get("Items", []):
        print("Student Id       :", item.get("StudId"))
        print("Student Name     :", item.get("FirstName"), item.get("LastName"))
        print("Department       :", item.get("Dept"))
        print("Age              :", item.get("Age"))
        print("---------------------------------------")

    print("Invocation completed successfully.")
    return {
        "statusCode": 200,
        "owner": "Nisha",
        "records_returned": len(resp.get("Items", []))
    }
