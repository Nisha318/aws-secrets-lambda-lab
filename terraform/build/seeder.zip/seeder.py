import os
import json
import boto3
from botocore.exceptions import ClientError

DDB_TABLE = os.environ["DDB_TABLE"]
SECRET_ARN = os.environ.get("SECRET_ARN")  # optional, for demo retrieval

dynamodb = boto3.resource("dynamodb")
secrets = boto3.client("secretsmanager")

def _get_demo_secret():
    """
    Optional: Retrieve a demo JSON secret.
    This is NOT required for DynamoDB access when using IAM role permissions.
    """
    if not SECRET_ARN:
        return None
    try:
        resp = secrets.get_secret_value(SecretId=SECRET_ARN)
        secret_str = resp.get("SecretString", "{}")
        return json.loads(secret_str)
    except ClientError as e:
        # Log and continue. Don't fail the function just because demo secret retrieval failed.
        print(f"Secret retrieval failed: {e}")
        return None

def lambda_handler(event, context):
    print("Seeding DynamoDB table...")
    demo_secret = _get_demo_secret()
    if demo_secret:
        print("Demo secret retrieved (keys not printed).")

    table = dynamodb.Table(DDB_TABLE)

    items = [
        {"StudId": 100, "FirstName": "Harry", "LastName": "Styles", "Dept": "IT", "Age": 28},
        {"StudId": 200, "FirstName": "Sam", "LastName": "Billings", "Dept": "BE", "Age": 22},
        {"StudId": 300, "FirstName": "Pete", "LastName": "Davidson", "Dept": "EE", "Age": 25},
    ]

    with table.batch_writer() as batch:
        for item in items:
            batch.put_item(Item=item)

    return {"statusCode": 200, "body": f"Seeded {len(items)} items into {DDB_TABLE}"}
